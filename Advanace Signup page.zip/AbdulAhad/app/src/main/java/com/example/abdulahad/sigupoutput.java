package com.example.abdulahad;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class sigupoutput extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sigupoutput);
    }
}